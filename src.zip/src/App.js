import React, { useState } from 'react';
 
function Screen1({ onNext }) {
  const [tableName, setTableName] = useState('');
  const [uniqueColumn, setUniqueColumn] = useState('');
  const [columnName, setColumnName] = useState('');
 
  const handleNext = () => {
    onNext(tableName, uniqueColumn, columnName);
  };
 
  return (
    <div>
      <h2>Screen 1</h2>
      <input
        type="text"
        placeholder="Table Name"
        value={tableName}
        onChange={(e) => setTableName(e.target.value)}
      />
      <input
        type="text"
        placeholder="Unique Column"
        value={uniqueColumn}
        onChange={(e) => setUniqueColumn(e.target.value)}
      />
      <input
        type="text"
        placeholder="Column Name"
        value={columnName}
        onChange={(e) => setColumnName(e.target.value)}
      />
      <button onClick={handleNext}>Next</button>
    </div>
  );
}
 
function Screen2({ tableData, userInputs, onUpdate }) {
  const handleInputChange = (index, e) => {
    const newInputs = [...userInputs];
    newInputs[index] = e.target.value;
    onUpdate(newInputs);
  };
 
  return (
    <div>
      <h2>Screen 2</h2>
      <table>
        <thead>
          <tr>
            <th>Table Name</th>
            <th>Column Name</th>
            <th>Distinct Value</th>
            <th>User Input</th>
          </tr>
        </thead>
        <tbody>
          {tableData.map((row, index) => (
            <tr key={index}>
              <td>{row.tableName}</td>
              <td>{row.columnName}</td>
              <td>{row.distinctValue}</td>
              <td>
                <input
                  type="text"
                  value={userInputs[index] || ''}
                  onChange={(e) => handleInputChange(index, e)}
                />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
 
function App() {
  const [screen, setScreen] = useState(1);
  const [tableData, setTableData] = useState([]);
  const [userInputs, setUserInputs] = useState([]);
 
  const handleNextScreen = (tableName, uniqueColumn, columnName) => {
    // Fetch data based on tableName, uniqueColumn, and columnName
    // Populate tableData with fetched data
    // Example data structure:
    const fetchedData = [
      { tableName, columnName, distinctValue: 'che' },
      { tableName, columnName, distinctValue: 'mum' },
      { tableName, columnName, distinctValue: 'bangalore' },
      { tableName, columnName, distinctValue: 'cochin' },
    ];
    setTableData(fetchedData);
    setUserInputs(new Array(fetchedData.length).fill(''));
    setScreen(2);
  };
 
  const handleUpdateTable = (newUserInputs) => {
    // Perform update operation using newUserInputs
    setUserInputs(newUserInputs);
    console.log('Updated user inputs:', newUserInputs);
  };
 
  return (
    <div>
      {screen === 1 && <Screen1 onNext={handleNextScreen} />}
      {screen === 2 && (
        <Screen2
          tableData={tableData}
          userInputs={userInputs}
          onUpdate={handleUpdateTable}
        />
      )}
    </div>
  );
}
 
export default App;