package com.UserManagementSystem.Repository;



import org.springframework.data.jpa.repository.JpaRepository;

import com.UserManagementSystem.Model.Users;
public interface UserRepository extends JpaRepository<Users, Integer> {		

}
