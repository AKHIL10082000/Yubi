package com.UserManagementSystem.Model;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Users {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	Integer Id;

    @Column(nullable = false, name = "FirstName")
    private String FirstName;
    
    @Column(nullable = false, name = "LastName")
    private String LastName;
    
    @Column(nullable = false, unique=true, name = "EmailId")
    private String EmailId;



}
