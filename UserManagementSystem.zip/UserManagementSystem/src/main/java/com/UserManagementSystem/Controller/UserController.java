package com.UserManagementSystem.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.UserManagementSystem.Model.Users;
import com.UserManagementSystem.Repository.UserRepository;
import com.UserManagementSystem.Service.UserService;
@RestController
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	public UserService userService;
	  
	
	  @Autowired
	  private UserRepository userRepository;
	
	@PostMapping(path = "/createUser", consumes = {"application/json", "application/xml" }, produces = {"application/json", "application/xml"  })
	private ResponseEntity<?> createUser( @RequestBody Users user) {
	
		Users createuser = userService.createUser(user);
		
		return ResponseEntity.status(HttpStatus.CREATED).body(createuser);
		
	}
	
	@PutMapping(path = "/updateUser", consumes = {"application/json", "application/xml" }, produces = {"application/json", "application/xml" })
	private ResponseEntity<?> updateUser( @RequestBody  Users user ){
			
			if(userRepository.existsById(user.getId())){
				Users updateuser = userService.updateUser(user);  	
				return ResponseEntity.status(HttpStatus.CREATED).body(updateuser);
				}
			else {
			return ResponseEntity.status(HttpStatus.CREATED).body("User is not present for given Id. Please enter the correct userId");
				}
		
	}
	
	@DeleteMapping("/deleteUser/{id}")
	private ResponseEntity<?> deleteUserById(@PathVariable(name="id", required = true) Integer id) {
		if(userRepository.existsById(id)){ 	
			return ResponseEntity.status(HttpStatus.OK).body(userService.deleteUserById(id));
			}
		else {
		return ResponseEntity.status(HttpStatus.CREATED).body("User is not present for given Id. Please enter the correct userId");
			}
	
	}
	
	@GetMapping(path = "/retrive={id}", produces = { "application/json", "application/xml" })
	private ResponseEntity<?> retriveUserById(@PathVariable(name="id", required = true) Integer id){
		if(userRepository.existsById(id)){ 	
			Users user = userService.findUserById(id).get();
			return ResponseEntity.status(HttpStatus.OK).body(user);
			}
		else {
		return ResponseEntity.status(HttpStatus.CREATED).body("User is not present for given Id. Please enter the correct userId");
			}
		
	}
}
