package com.UserManagementSystem.Service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.UserManagementSystem.Model.Users;
import com.UserManagementSystem.Repository.UserRepository;
@Service
public class UserService {
	 
	@Autowired
	public UserRepository userRepository;

	//Delete User by Id
	public String deleteUserById(Integer id) {
		// TODO Auto-generated method stub
		 userRepository.deleteById(id);
		 return "User deleted By Id";
	}
	//Find User by Id
	public Optional<Users> findUserById(Integer id) {
		// TODO Auto-generated method stub
		return userRepository.findById(id);
	}
	//Update User by Id
	public Users updateUser(Users user) {
		// TODO Auto-generated method stub
		 userRepository.save(user);
		 return user;
	}
	//Create User
	public Users createUser(Users user) {
		// TODO Auto-generated method stub
		 userRepository.save(user);
		 return user;
	}

}
